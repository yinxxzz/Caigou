# 数据源与查询口径

## 数仓订单

用途：

- `本期消耗情况`：统计截止当前订单量。
- `下期订单预估`：查询近 3 个月、去年同期同口径订单量。

优先口径：

- 表：`dw_dwd.dwd_eng_order_course_detail_da`
- 分区：`dt` 取最新分区或业务要求分区。
- 时间：使用 `pay_dt`，不要用 `order_dt`。
- 课程：系统课，历史对齐时使用 `lesson_type = '1'` 或项目已确认的系统课字段。
- 状态：全部订单状态，含退费，不额外过滤退费。
- keyfrom：
  - 一级 keyfrom：`keyfrom_p1 IN (...)`
  - keyfrom 关键词：`keyfrom LIKE '%kw1%' OR keyfrom LIKE '%kw2%'`
  - 两组之间必须是 `AND`

SQL 结构示例：

```sql
SELECT
    pay_dt
    ,COUNT(DISTINCT order_id) AS order_cnt
FROM dw_dwd.dwd_eng_order_course_detail_da
WHERE dt = '${latest_dt}'
    AND pay_dt >= '${start_date}'
    AND pay_dt <= '${end_date}'
    AND lesson_type = '1'
    AND keyfrom_p1 IN (${keyfrom_p1_values})
    AND (
        keyfrom LIKE '%${keyword_1}%'
        OR keyfrom LIKE '%${keyword_2}%'
    )
GROUP BY pay_dt
```

如果字段名和实际表结构冲突，先查表结构再改 SQL，不要凭空替换。

## 供应链运单消耗

用途：

- 查询 SKU 实际消耗。
- 实际消耗定义：产生运单即计入，不只看已发货。

固定口径：

- 运单类型：系统课加赠。
- `shipmentSearchTypes=31`
- `channelId=1051`
- 渠道名：辅导服务-用户增长-扩科
- 分页从 `page=0` 开始。

聚合字段：

- `goodsCode`
- `goodsName`
- `quantity`

输出聚合：

- `shipmentCount`
- `skuTotalQuantity`
- `skuItems`
- `dailyConsumptionTrend`

## 供应链实时库存

用途：

- 判断本期剩余是否够用。
- 采购测算时判断是否需要采购、调拨或替换。

复用项目 skill：`supply-chain-inventory-realtime`。

固定参数：

- 页面：`https://lean.zhenguanyu.com/#/inventory/stock-manage`
- 接口：`GET https://conan.zhenguanyu.com/bolt-logistics-admin/api/channel-inventories/`
- `bizId=6000`
- `channelIds=1051`
- 默认 `pageSize=100`

Cookie 服务：

- 优先：`http://127.0.0.1:18899`
- 备用：`http://10.134.208.184:18899`

如果 Cookie 服务不可用、401、跳登录页或请求失败，必须告诉用户当前无法查询实时库存，不能把缓存结果写成实时库存。

## 候补池

用途：

- 下期采购测算时找可采购新品或替换品。

来源：

- 石墨文档：`https://shimo.zhenguanyu.com/sheets/YdypXjyRpcrYWrjq/CmVe2`
- Sheet：`候补池`
- 范围：`A1:I452`

使用原则：

- 一个月读取一次即可。
- 优先使用工作台或本地已保存的候补池快照。
- 没有候补池数据时，可以先输出老品复用与风险提醒，但不要编造新品 SKU。

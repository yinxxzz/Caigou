# 工作台回填 JSON 格式

## 本期消耗情况

工作台粘贴位置：`本期消耗情况` → `Cursor 返回结果（JSON）`。

```json
{
  "progressRate": 25,
  "completedOrders": 1000,
  "projectedTotalOrders": 4000,
  "remainingEstimatedOrders": 3000,
  "consumedSkuQuantity": 1200,
  "projectedTotalSkuQuantity": 4800,
  "remainingEstimatedSkuQuantity": 3600,
  "inventoryRiskSummary": "1 个 SKU 有库存风险：得力地球仪",
  "skuItems": [
    {
      "goodsCode": "Z050519103753100",
      "goodsName": "直采赠品-得力地球仪-100",
      "consumedQuantity": 260,
      "projectedTotalQuantity": 1040,
      "remainingEstimatedQuantity": 780,
      "availableQuantity": 600,
      "endingAvailableQuantity": -180,
      "status": "有风险"
    }
  ]
}
```

字段说明：

- `progressRate`：活动已过时间比例，整数百分比。
- `completedOrders`：截止当前实际订单量。
- `projectedTotalOrders`：按当前速度预估全期订单。
- `remainingEstimatedOrders`：预估活动结束前剩余订单。
- `endingAvailableQuantity`：当前库存 - 剩余预计消耗。
- `status`：优先使用 `够用` / `有风险`。

## 下期订单预估

工作台粘贴位置：`新增活动` → `下期订单预估` → `Cursor 返回的订单预估结果（JSON）`。

```json
{
  "nextEstimatedOrders": 4200,
  "forecastBasis": "近 3 个月同口径订单分别为 3600/3900/4100，去年同期为 3800；考虑本期活动主题和渠道稳定性，保守预估下期 4200 单。"
}
```

字段说明：

- `nextEstimatedOrders`：下期活动预估订单量，整数。
- `forecastBasis`：必须说明参考月份、去年同期、趋势和保守/激进判断。

## 下期采购测算

工作台粘贴位置：`新增活动` → `下期采购测算` → `Cursor 返回的采购测算结果（JSON）`。

```json
{
  "procurementAdviceText": "建议保留 2 个老品作为主推，新增 1 个低成本新品测试。词典笔库存不足，不建议继续作为高权重选项。",
  "riskSummary": "主要风险是词典笔库存不足、地球仪本期剩余消耗较高；新品需要控制采购量，避免滞销。",
  "skus": [
    {
      "packageName": "扩科礼包 A",
      "isNewProduct": false,
      "goodsCode": "Z050620100212100",
      "goodsName": "直采-我们的中国立体书-100",
      "displayName": "我们的中国立体书",
      "category": "图书",
      "unitCost": 28,
      "suggestedPurchaseQuantity": 1800,
      "finalPurchaseQuantity": 1800,
      "status": "采购",
      "remark": "老品消耗稳定，库存预扣后仍需补采。"
    }
  ]
}
```

字段说明：

- `procurementAdviceText`：采购建议正文，说明保留、替换、新增的判断。
- `riskSummary`：库存、成本、新品滞销、供应不确定性的风险。
- `skus`：建议 SKU 表，会直接回填到工作台最终定稿 SKU 表。
- `status`：必须是 `采购` / `借调` / `备货` / `无需处理` 之一。

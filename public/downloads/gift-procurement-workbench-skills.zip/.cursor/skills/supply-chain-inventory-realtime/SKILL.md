---
name: supply-chain-inventory-realtime
description: Query real-time gift inventory from the supply-chain backend at lean.zhenguanyu.com. Use when the user mentions 供应链库存、实时库存、lean库存、查库存、礼盒库存、赠品库存, or asks whether requested gifts have enough stock.
---

# 供应链实时库存查询

## 适用场景

用户要查“供应链库存 / 实时库存 / lean库存 / 查库存 / 礼盒库存 / 赠品库存”时使用本 Skill。

不要把这个需求理解为从斑马驿站获取库存。库存来源是供应链后台：

- 页面入口：`https://lean.zhenguanyu.com/#/inventory/stock-manage`
- 实时接口：`GET https://conan.zhenguanyu.com/bolt-logistics-admin/api/channel-inventories/`
- 默认参数：`bizId=6000`、`channelIds=1051`
- 默认每页：`pageSize=100`

## 登录态约定

供应链后台依赖 `lean.zhenguanyu.com` 登录 Cookie。

优先使用当前项目已有的 Cookie 服务配置：

- 健康检查：`GET http://127.0.0.1:18899/health`
- 获取 Cookie：`GET http://127.0.0.1:18899/cookie`
- 强制刷新：`GET http://127.0.0.1:18899/cookie?refresh=1`
- 如果本机 `127.0.0.1:18899` 不通，尝试大圣维护的服务地址：`http://10.134.208.184:18899`

如果 Cookie 服务不可用、Cookie 失效、接口返回 401、跳登录页或请求失败，直接告诉用户：当前没有和大圣维护的供应链登录态同步，需要大圣刷新或同步 Cookie 后再查实时库存。

## 查询流程

1. 从用户消息或图片里提取要查的品名。
2. 检查 Cookie 服务是否可用。
3. 分页请求供应链实时库存接口，优先拉全量后本地匹配，避免只查第一页漏结果。
4. 用品名关键词匹配 `goodsName`、`displayName`、`goodsCode`。
5. 同一物料编码跨仓时，按仓库列出，并汇总可用库存。
6. 如果只有模糊命中，要明确标注“疑似匹配”，不要当成精确结果。

## 输出格式

默认给简版结果：

```markdown
库存来源：供应链后台实时库存，渠道 `1051`

- 品名：可用库存 `数量`，仓库：A `数量` / B `数量`
- 品名：未精确命中；疑似匹配 `物料名`，可用库存 `数量`
```

如果用户要明细，再补充物料编码、物料名、锁定库存、总可用字段。

## 注意事项

- 不要把本地快照或缓存结果称为“实时库存”。
- 如果只能查到缓存，必须标注缓存时间和“非实时”。
- `availableQuantity` 是当前可用库存；`lockedQuantity` 是锁定库存；`sumAvailableQuantity` 只作为辅助字段，不要替代当前可用库存。
- 默认渠道是 `1051`，除非用户给了其他 `channelIds`。

# 赠品采购预测工作台 Skill 包

## 包含内容

- gift-procurement-advisor：处理本期消耗回填、下期订单预估、下期采购测算。
- supply-chain-inventory-realtime：查询供应链后台实时库存。

## 安装方式

1. 在工作台下载本压缩包。
2. 将压缩包解压到工作台项目根目录。
3. 确认项目根目录下存在 `.cursor/skills/gift-procurement-advisor` 和 `.cursor/skills/supply-chain-inventory-realtime`。
4. 重新打开 Cursor 项目或刷新窗口。
5. 在工作台复制数据包给 Cursor，Cursor 会按场景自动使用对应 Skill。
